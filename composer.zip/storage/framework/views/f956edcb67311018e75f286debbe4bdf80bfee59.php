

<?php $__env->startSection('content'); ?>

<header id="header" class="header-transparent header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': false, 'stickyStartAt': 70, 'stickyChangeLogo': false, 'stickyHeaderContainerHeight': 70}">
        <div class="header-body border-top-0 bg-dark box-shadow-none">
            <div class="header-container container">
                <div class="header-row">
                    <div class="header-column">
                        <div class="header-row">
                            <div class="header-logo">
                                <a href="index.html"><img alt="Porto" width="100" height="48" data-sticky-width="82" data-sticky-height="40" data-sticky-top="0" src="img/logo-default-slim-dark.png"></a>
                            </div>
                        </div>
                    </div>
                    <div class="header-column justify-content-end">
                        <div class="header-row">
                            <div class="header-nav header-nav-line header-nav-bottom-line header-nav-bottom-line-no-transform header-nav-bottom-line-active-text-light header-nav-bottom-line-effect-1 header-nav-light-text">
                                <div class="header-nav-main header-nav-main-square header-nav-main-dropdown-no-borders header-nav-main-dropdown-border-radius header-nav-main-text-capitalize header-nav-main-text-size-3 header-nav-main-effect-1 header-nav-main-sub-effect-1">
                                    <nav class="collapse">
                                        <ul class="nav nav-pills" id="mainNav">
                                            <li class="">
                                                <a class="dropdown-item dropdown-toggle" href="index.html">
                                                    Home
                                                </a>
                                            </li>
                                            <li class="">
                                                <a class="dropdown-item dropdown-toggle" href="<?php echo e(route('news.index')); ?>">
                                                    News
                                                </a>
                                            </li>
                                            <li class="">
                                                <a class="dropdown-item dropdown-toggle" href="#">
                                                    Blog
                                                </a>
                                            </li>
                                            <li class="">
                                                <a class="dropdown-item dropdown-toggle" href="#">
                                                    Quotes
                                                </a>
                                            </li>
                                            <li class="">
                                                <a class="dropdown-item dropdown-toggle" href="#">
                                                    Contact
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                
                                <button class="btn header-btn-collapse-nav" data-bs-toggle="collapse" data-bs-target=".header-nav-main nav"><i class="fa fa-bars"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>


    

    <div role="main" class="main">

				<section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1 class="text-dark font-weight-bold text-8">Grid 3 Columns</h1>
								<span class="sub-title text-dark">Check out our Latest News!</span>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb d-block text-center">
									<li><a href="#">Home</a></li>
									<li class="active">Blog</li>
								</ul>
							</div>
						</div>
					</div>
				</section>

                <form action="<?php echo e(route('news.index')); ?>" method="GET">
                    <select name="category">
                        <option value="general" <?php echo e($category == 'general' ? 'selected' : ''); ?>>General</option>
                        <option value="business" <?php echo e($category == 'business' ? 'selected' : ''); ?>>Business</option>
                        <option value="entertainment" <?php echo e($category == 'entertainment' ? 'selected' : ''); ?>>Entertainment</option>
                        <option value="health" <?php echo e($category == 'health' ? 'selected' : ''); ?>>Health</option>
                        <option value="science" <?php echo e($category == 'science' ? 'selected' : ''); ?>>Science</option>
                        <option value="sports" <?php echo e($category == 'sports' ? 'selected' : ''); ?>>Sports</option>
                        <option value="technology" <?php echo e($category == 'technology' ? 'selected' : ''); ?>>Technology</option>
                    </select>
                    <button type="submit">Filter</button>
                </form>

				<div class="container py-4">

					<div class="row">
						<div class="col">
							<div class="blog-posts">

								<div class="row">

                                    <?php $__currentLoopData = $articles->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-md-4">
                                            <article class="post post-medium border-0 pb-0 mb-5">
                                                <div class="post-image">
                                                    <?php
                                                        $cekImage = $article->urlToImage;
                                                    ?>
                                                    <!-- is_null($cekImage) bisa dengan pemanggilan seperti ini -->
                                                    <a href="<?php echo e($article->url); ?>"> 
                                                        <?php if($cekImage == null): ?>
                                                        <img src="<?php echo e(asset('img/new/imgnotfound.png')); ?>" class="img-fluid rounded-0" alt="No Image Found" />
                                                        <?php else: ?>
                                                        <img src="<?php echo e($article->urlToImage); ?>" class="img-fluid rounded-0" alt="No Image Found" />
                                                        <?php endif; ?>
                                                    </a>
                                                </div>

                                                <div class="post-content">

                                                    <h2 class="font-weight-semibold text-5 line-height-6 mt-3 mb-2"><a href="<?php echo e($article->url); ?>"><?php echo e($article->title); ?></a></h2>
                                                    <!-- <p><?php echo e($article->description); ?></p> -->
                                                    <p><?php echo e(substr($article->description, 0, 100)); ?>...</p>

                                                    <div class="post-meta">
                                                        <span><i class="far fa-user"></i><a href="#"><?php echo e($article->author); ?></a> </span>
                                                        <span><i class="far fa-folder"></i><a href="#"><?php echo e($category); ?></a> </span>
                                                        <span><i class="far fa-calendar"></i> <a href="#"><?php echo e(substr($article->publishedAt, 0, 10)); ?></a></span>
                                                        <span class="d-block mt-2"><a href="<?php echo e($article->url); ?>" class="btn btn-xs btn-light text-1 text-uppercase">Read More</a></span>
                                                    </div>

                                                </div>
                                            </article>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</div>

								<div class="row">
									<div class="col">
										<ul class="pagination float-end">
											<li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-left"></i></a></li>
											<li class="page-item active"><a class="page-link" href="#">1</a></li>
											<li class="page-item"><a class="page-link" href="#">2</a></li>
											<li class="page-item"><a class="page-link" href="#">3</a></li>
											<li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-right"></i></a></li>
										</ul>
									</div>
								</div>

							</div>
						</div>

					</div>

				</div>

			</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\daily\resources\views/news/index.blade.php ENDPATH**/ ?>